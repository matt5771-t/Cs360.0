package com.example.inventorytracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private DatabaseHelper dbHelper;
    private GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        gridView = findViewById(R.id.inventoryGridView);
        Button triggerAlertButton = findViewById(R.id.triggerAlertButton);

        // Load grid view data from database
        loadInventoryGrid();

        // Check and request runtime permissions for SMS notifications
        triggerAlertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAndRequestSmsPermission();
            }
        });
    }

    private void loadInventoryGrid() {
        Cursor cursor = dbHelper.getAllItems();
        String[] fromColumns = {DatabaseHelper.COLUMN_ITEM_NAME, DatabaseHelper.COLUMN_ITEM_QUANTITY};
        int[] toViews = {android.R.id.text1, android.R.id.text2};

        // Populate grid view with database items
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,
                android.R.layout.simple_list_item_2,
                cursor,
                fromColumns,
                toViews,
                0
        );
        gridView.setAdapter(adapter);
    }

    private void checkAndRequestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Request permission at runtime
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            sendLowStockSmsAlert();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // User granted permission: send alert
                sendLowStockSmsAlert();
            } else {
                // User denied permission: app continues to function normally without crashing
                Toast.makeText(this, "SMS permission denied. Notification feature disabled, but app remains fully functional.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void sendLowStockSmsAlert() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("5551234567", null, "Alert: Inventory stock level is critically low!", null, null);
            Toast.makeText(this, "Low stock SMS notification sent successfully.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS message.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}